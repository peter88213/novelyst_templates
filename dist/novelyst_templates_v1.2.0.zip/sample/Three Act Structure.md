# nv

### ACT 1

Setup

### ACT 2

Confrontation

### ACT 3

Resolution

# pl

## Arcs

### A-Storyline

Applying a three-act structure

#### Inciting Incident

#### Plot Point 1

#### Midpoint

#### Plot Point 2

#### Climax