# nv

### ACT 1

### ACT 2

### ACT 3

# pl

## Arcs

### A-Storyline

Applying a beat sheet as described in "Save The Cat! Writes A Novel" by Jessica Brody.

#### Opening Image

A "so far" snapshot of your hero and his world.

#### Theme Stated

A statement from a character (usually not the hero) that gives a hint of what the hero's story arc is about.

#### Setup

#### Catalyst

#### Debate

#### Break into 2

#### B Story

#### Fun and Games

#### Midpoint

#### Bad Guys close in

#### All is lost

#### Dark night of the soul

#### Break into 3

#### Finale

#### Final Image

