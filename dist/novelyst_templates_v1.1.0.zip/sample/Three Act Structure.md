# nv

### ACT 1

### ACT 2

### ACT 3

# pl

## Arcs

### A-Storyline

Applying a Three Act storyline.

#### Regular Life

#### Inciting Event

#### Plot Point 1

#### Midpoint

#### Plot Point 2

#### Climax

#### New Life
