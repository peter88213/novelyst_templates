# nv

### ACT 1

### ACT 2

### ACT 3

### ACT 4

# pl

## Arcs

### A-Storyline

Applying the plot structure as described in "Fool Proof Outline - A No-Nonsense System For Productive Planning, Outlining, & Drafting Novels" by Christopher Downing.

#### Setting The Stage

#### Catalyst

#### Deal With Catalyst

#### First Door Of No Return

#### Journey Begins

#### Raised Stakes

#### Advancing To Goal

#### Self-Reflective Mid-Point

#### Intensifying Conflict

#### Surprise Variables Raise Stakes

#### Protagonist Suffers The Effects

#### Second Door Of No Return

#### Stakes Raised To Extreme

#### Preparing For Final Battle

#### The Final Battle

#### New Status Quo

