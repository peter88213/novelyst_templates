"""A "Story Templates" plugin for noveltree.

Version 2.4.1

Adds a 'Add Story Templates' entry to the 'Tools' menu to open a window
with a combobox that lists all available themes. 
The selected theme will be persistently applied.  

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_templates
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
import tkinter as tk
import webbrowser
from tkinter import messagebox
from tkinter import filedialog
from pathlib import Path
import sys
import gettext
import locale

__all__ = ['Error',
           '_',
           'norm_path',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           'APPLICATION',
           'PLUGIN',
           'ROOT_PREFIX',
           'ARC_PREFIX',
           'ARC_POINT_PREFIX',
           'CHAPTER_PREFIX',
           'CH_ROOT',
           'AC_ROOT',
           ]
ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
ARC_PREFIX = 'ac'
ARC_POINT_PREFIX = 'ap'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
AC_ROOT = f'{ROOT_PREFIX}{ARC_PREFIX}'


class Error(Exception):
    pass


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_templates', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Story Templates')
PLUGIN = f'{APPLICATION} plugin 2.4.1'


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)



class MdTemplate:
    DESCRIPTION = _('Story Template')
    EXTENSION = '.md'
    ARC_MARKER = '-'

    def __init__(self, filePath, ui):
        self.filePath = filePath
        self._ui = ui

    def read(self):
        try:
            with open(self.filePath, 'r', encoding='utf-8') as f:
                mdLines = f.readlines()
        except(FileNotFoundError):
            raise Error(f'{_("File not found")}: "{norm_path(self.filePath)}".')
        except:
            raise Error(f'{_("Cannot read file")}: "{norm_path(self.filePath)}".')

        if mdLines[0].startswith('# nv'):
            self.read_novelyst_structure(mdLines)
        else:
            self.read_noveltree_structure(mdLines)

    def read_novelyst_structure(self, mdLines):
        chId = self._ui.c_add_chapter(targetNode=CH_ROOT, title=_('Stages'), chLevel=2, chType=3)
        scId = chId
        arcSection = False
        newElement = None
        desc = []
        for mdLine in mdLines:
            mdLine = mdLine.strip()
            if mdLine.startswith('#'):
                if newElement is not None:
                    newElement.desc = ''.join(desc).strip().replace('  ', ' ')
                    desc = []
                    newElement = None
                if mdLine.startswith('####'):
                    if arcSection:
                        newTitle = mdLine[5:]
                        scId = self._ui.c_add_stage(targetNode=scId, title=newTitle, scType=3)
                        if scId:
                            newElement = self._ui.novel.sections[scId]
                elif mdLine.startswith('###'):
                    if not arcSection:
                        newTitle = mdLine[4:]
                        scId = self._ui.c_add_stage(targetNode=scId, title=newTitle, scType=2)
                        if scId:
                            newElement = self._ui.novel.sections[scId]
                elif mdLine.strip() == '# pl':
                    arcSection = True
            elif mdLine:
                desc.append(f'{mdLine} ')
            else:
                desc.append('\n')
        try:
            newElement.desc = ''.join(desc).strip().replace('  ', ' ')
        except AttributeError:
            pass

    def read_noveltree_structure(self, mdLines):
        if self._ui.novel.chapters:
            self.list_stages(mdLines)
        else:
            self.create_chapter_structure(mdLines)

    def create_chapter_structure(self, mdLines):
        i = 0
        chId = CH_ROOT
        addChapter = True
        newElement = None
        desc = []
        for mdLine in mdLines:
            mdLine = mdLine.strip()
            if mdLine.startswith('#'):
                if newElement is not None:
                    newElement.desc = ''.join(desc).strip().replace('  ', ' ')
                    desc = []
                    newElement = None
                if mdLine.startswith('## '):
                    if addChapter:
                        i += 1
                        chId = self._ui.c_add_chapter(targetNode=chId, title=f"{_('Chapter')} {i}", chLevel=2, chType=0)
                        scId = chId
                    newTitle = mdLine[3:].strip()
                    scId = self._ui.c_add_stage(targetNode=scId, title=newTitle, scType=3)
                    newElement = self._ui.novel.sections[scId]
                    scId = self._ui.c_add_section(targetNode=scId, title=_('New Section'), scType=0, status=1)
                    addChapter = True
                elif mdLine.startswith('# '):
                    i += 1
                    chId = self._ui.c_add_chapter(targetNode=chId, title=f"{_('Chapter')} {i}", chLevel=2, chType=0)
                    newTitle = mdLine[2:].strip()
                    scId = self._ui.c_add_stage(targetNode=chId, title=newTitle, stageLevel=1)
                    newElement = self._ui.novel.sections[scId]
                    addChapter = False
                else:
                    scId = None
            elif mdLine:
                desc.append(f'{mdLine} ')
            else:
                desc.append('\n')
        newElement.desc = ''.join(desc).strip().replace('  ', ' ')

    def list_stages(self, mdLines):
        chId = self._ui.c_add_chapter(targetNode=CH_ROOT, title=_('Stages'), chLevel=2, chType=3)
        scId = chId
        newElement = None
        desc = []
        for mdLine in mdLines:
            mdLine = mdLine.strip()
            if mdLine.startswith('#'):
                if newElement is not None:
                    newElement.desc = ''.join(desc).strip().replace('  ', ' ')
                    desc = []
                    newElement = None
                if mdLine.startswith('## '):
                    newTitle = mdLine[3:].strip()
                    scId = self._ui.c_add_stage(targetNode=scId, title=newTitle, scType=3)
                elif mdLine.startswith('# '):
                    newTitle = mdLine[2:].strip()
                    scId = self._ui.c_add_stage(targetNode=scId, title=newTitle, scType=2)
                else:
                    scId = None
                if scId:
                    newElement = self._ui.novel.sections[scId]
            elif mdLine:
                desc.append(f'{mdLine} ')
            else:
                desc.append('\n')
        newElement.desc = ''.join(desc).strip().replace('  ', ' ')

    def write(self):
        mdLines = []
        for chId in self._ui.novel.tree.get_children(CH_ROOT):
            for scId in self._ui.novel.tree.get_children(chId):
                if self._ui.novel.sections[scId].scType == 2:
                    mdLines.append(f'# {self._ui.novel.sections[scId].title}')
                    desc = self._ui.novel.sections[scId].desc
                    if desc:
                        mdLines.append(desc.replace('\n', '\n\n'))
                elif self._ui.novel.sections[scId].scType == 3:
                    mdLines.append(f'## {self._ui.novel.sections[scId].title}')
                    desc = self._ui.novel.sections[scId].desc
                    if desc:
                        mdLines.append(desc.replace('\n', '\n\n'))

        content = '\n\n'.join(mdLines)
        try:
            with open(self.filePath, 'w', encoding='utf-8') as f:
                f.write(content)
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')



class Plugin():
    """A 'Story Templates' plugin class.
    
    Public methods:
        disable_menu() -- disable menu entries when no project is open.
        enable_menu() -- enable menu entries when a project is open.    
    """
    VERSION = '2.4.1'
    NOVELYST_API = '0.4'
    DESCRIPTION = 'A "Story Templates" manager'
    URL = 'https://peter88213.github.io/nv_templates'
    _HELP_URL = 'https://peter88213.github.io/nv_templates/usage'

    def install(self, ui):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            ui -- reference to the NoveltreeUi instance of the application.
        """
        self._ui = ui
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            self._templateDir = f'{homeDir}/.noveltree/templates'
        except:
            self._templateDir = '.'

        self._templatesMenu = tk.Menu(self._ui.toolsMenu, tearoff=0)
        self._templatesMenu.add_command(label=_('Load'), command=self._load_template)
        self._templatesMenu.add_command(label=_('Save'), command=self._save_template)
        self._templatesMenu.add_command(label=_('Open folder'), command=self._open_folder)

        self._ui.newMenu.add_command(label=_('Create from template...'), command=self._new_project)

        self._ui.toolsMenu.add_cascade(label=APPLICATION, menu=self._templatesMenu)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')
        self._fileTypes = [(MdTemplate.DESCRIPTION, MdTemplate.EXTENSION)]

        self._ui.helpMenu.add_command(label=_('Templates plugin Online help'), command=lambda: webbrowser.open(self._HELP_URL))

    def disable_menu(self):
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

    def enable_menu(self):
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

    def _load_template(self):
        fileName = filedialog.askopenfilename(filetypes=self._fileTypes,
                                              defaultextension=self._fileTypes[0][1],
                                              initialdir=self._templateDir)
        if fileName:
            try:
                templates = MdTemplate(fileName, self._ui)
                templates.read()
            except Error as ex:
                messagebox.showerror(_('Template loading aborted'), str(ex))

    def _new_project(self):
        self._ui.new_project()
        self._load_template()

    def _open_folder(self):
        try:
            os.startfile(norm_path(self._templateDir))
        except:
            try:
                os.system('xdg-open "%s"' % norm_path(self._templateDir))
            except:
                try:
                    os.system('open "%s"' % norm_path(self._templateDir))
                except:
                    pass

    def _save_template(self):
        fileName = filedialog.asksaveasfilename(filetypes=self._fileTypes,
                                              defaultextension=self._fileTypes[0][1],
                                              initialdir=self._templateDir)
        if not fileName:
            return

        try:
            templates = MdTemplate(fileName, self._ui)
            templates.write()
        except Error as ex:
            messagebox.showerror(_('Cannot save template'), str(ex))

        self._ui.set_info_how(_('Template saved.'))

