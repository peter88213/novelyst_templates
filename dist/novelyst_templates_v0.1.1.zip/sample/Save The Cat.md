# nv

### ACT 1
### ACT 2
### ACT 3

# pl

## Arcs

### A - Storyline

#### Opening Image

Ein "bisher"-Schnappschuss deines Helden und seiner Welt.

#### Theme Stated

Eine Aussage von einer Figur (üblicherweise nicht der Held), die einen Hinweis gibt, worum es beim Erzählbogen des Helden geht (das heißt, was der Held vor dem Ende des Buchs lernen/entdecken muss). 

#### Setup

Eine Erforschung des Status Quo des Lebens des Helden und all seiner Macken, wo wir lernen, wie das Leben des Helden vor seiner epischen Transformation aussieht. Hier führen wir auch andere unterstützende Figuren und das vordergründige Ziel des Helden ein. Doch am wichhtigsten: wir zeigen den Widerstand des Helden zur Veränderung (die Lektion Lernen), während wir auch zeigen, was auf dem Spiel steht, sollte sich der Held nicht ändern.

#### Catalyst

Ein zündendes Vorkommnis (oder lebensveränderndes Ereignis), das den Helden in eine neue Welt katapultiert, oder zum Umdenken bringt. Ein Schlag, der stark genug sein sollte, um die Rückkehr des Helden zum Status Quo des Setup zu verhindern.

#### Debate

Die Reaktion, eine Sequenz, in der der Held debattiert, was als Nächstes zu tun ist. Sie wird gewöhnlich als Frage präsentiert (wie "sollte ich gehen?"). Der Zweck ist, die Zögerlichkeit zur Veränderung zu zeigen.


#### Break into 2


#### B Story


#### Fun and Games


#### Midpoint


#### Bad Guys close in


#### All is lost


#### Dark night of the soul


#### Break into 3


#### Finale


#### Final Image

