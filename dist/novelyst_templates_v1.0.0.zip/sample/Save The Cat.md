# nv

### ACT 1

### ACT 2

### ACT 3

# pl

## Arcs

### A - Storyline

Applying a beat sheet as described in "Save The Cat! Writes A Novel" by Jessica Brody.

#### Opening Image

A "so far" snapshot of your hero and his world.

#### Theme Stated

A statement from a character (usually not the hero) that gives a hint of what the hero's story arc is about (that is, what the hero must learn/discover before the end of the book). 

#### Setup

An exploration of the status quo of the hero's life and all its quirks, where we learn what the hero's life is like before his epic transformation. Here we also introduce other supporting characters and the hero's ostensible goal. But most importantly, we show the hero's resistance to change ("learning the lesson"), while also showing what is at stake should the hero not change.

#### Catalyst

An igniting incident (or life-changing event) that catapults the hero into a new world, or causes him to rethink. A blow that should be strong enough to prevent the hero's return to the setup's status quo.

#### Debate

The reaction, a sequence in which the hero debates what to do next. It is usually presented as a question (like "should I go?"). The purpose is to show hesitation to change.

#### Break into 2

#### B Story

#### Fun and Games

#### Midpoint

#### Bad Guys close in

#### All is lost

#### Dark night of the soul

#### Break into 3

#### Finale

#### Final Image

